# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '2b56ed40499fcaeba0f74ed8b5ec13e78e10f0ef66ebac0fe5e05ca5d91382180f4bf5b3d5b4e3f1ecb743ba4e1aa0b02dd175bdcbc7fcb7050466d7bffb3f3b'
